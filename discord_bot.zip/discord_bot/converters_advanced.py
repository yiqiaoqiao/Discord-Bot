import settings
import discord
from discord.ext import commands
import random

logger = settings.logging.getLogger("bot")


# Class used for slap class.
# If user nicknames, it will use the name that user changed in server.
# Else it will use user's discord id.
class Slapper(commands.Converter):
    use_nicknames: bool

    def __init__(self, *, use_nicknames) -> None:
        self.use_nicknames = use_nicknames

    async def convert(self, ctx, argument):
        # Choose a random user from guild. Now it is only this bot
        someone = random.choice(ctx.guild.members)
        nickname = ctx.author
        if self.use_nicknames and ctx.author.nick is not None:
            nickname = ctx.author.nick
        return f"{nickname} slaps {someone} with {argument}"


def run():
    intents = discord.Intents.all()
    bot = commands.Bot(command_prefix="!", intents=intents)

    @bot.event
    async def on_ready():
        logger.info(f"User: {bot.user} (ID:{bot.user.id})")

    @bot.command()
    # If user type !add with 2 argument, it will add 2 numbers together
    async def add(ctx, one: int, two: int):
        await ctx.send(one + two)

    @bot.command()
    # If user type !joined with member's name, it will print the discord id of the member and when he/she joined the server
    async def joined(ctx, who: discord.Member):
        await ctx.send(f"{who}: {who.joined_at}")  # who and when member join the server

    @bot.command()
    # If user type !slap with member's name, it will print the nickname of the person and slape the bot with a reason
    async def slap(ctx, reason: Slapper(use_nicknames=True)):
        await ctx.send(reason)

    bot.run(settings.DISCORD_API_SECRET, root_logger=True)


if __name__ == "__main__":
    run()
