import discord
from discord import app_commands


# My group class that groups slash commands.
class MyGroup(app_commands.Group):
    # These are MyGroup commands
    @app_commands.command()
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message("ping")

    @app_commands.command()
    async def pong(self, interaction: discord.Interaction):
        await interaction.response.send_message("pong")


# on_ready() expect setup functsion
async def setup(bot):
    # Create an instance of MyGroup
    # User will need to use /greet cmd to use the command
    my_group = MyGroup(name="greet", description="Ping Pong!")
    # Add the group to the bot's command tree
    bot.tree.add_command(my_group)
