import settings
import discord
from discord.ext import commands

logger = settings.logging.getLogger("bot")


def run():
    intents = discord.Intents.all()
    bot = commands.Bot(command_prefix="!", intents=intents)

    @bot.event
    async def on_ready():
        logger.info(f"User: {bot.user} (ID:{bot.user.id})")
        bot.tree.copy_global_to(guild=settings.GUILDS_ID)
        await bot.tree.sync(guild=settings.GUILDS_ID)  # hybrid command is sync in tree.

    # By using hybrid command, we can now use !pong or /pong to activate the command.
    @bot.hybrid_command()
    async def pong(ctx):
        await ctx.send("ping")

    # We can now access the tree directly
    # We don't have ctx but now interactions.
    # By setting names to greetings, we can now either use /oi or /greetings

    @bot.tree.command(description="Welcomes user", name="greetings")
    async def oi(interaction: discord.Interaction):
        # Now we are having interaction with the user
        # By setting ephemeral to True, only the user mentioned can see the message.
        await interaction.response.send_message(
            f"oioi {interaction.user.mention}", ephemeral=True
        )

    # nsfw is not safe for work
    # When setting nsfw to True, this command can only used in age restricted channel.
    @bot.tree.command(nsfw=True)
    async def restricted(interaction: discord.Interaction):
        await interaction.response.send_message(f"age restricted", ephemeral=True)

    bot.run(settings.DISCORD_API_SECRET, root_logger=True)


if __name__ == "__main__":
    run()
