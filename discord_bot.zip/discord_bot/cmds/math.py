from discord.ext import commands


@commands.group()
# Bot group that contains all math commands
# Example: !math add 1 1
# You can add layers of bot group within each other
async def math(ctx):
    # Check if the command belongs to math group or not
    if ctx.invoked_subcommand is None:
        await ctx.send(f"No, {ctx.subcommand_passed} does not belong to math")


@math.command()
# If user type !add with 2 argument, it will add 2 numbers together
async def add(ctx, one: int, two: int):
    await ctx.send(one + two)


@math.command()
# If user type !subtract with 2 argument, it will subtract the two numbers
async def subtract(ctx, one: int, two: int):
    await ctx.send(one - two)


# Method automatically called when you load extension in discord.py
# Require to access bot instance
async def setup(bot):
    bot.add_command(math)  # User now can use !math add
    bot.add_command(add)  # This case user could either use !math add or !add
