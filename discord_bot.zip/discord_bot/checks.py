import settings
import discord
from discord.ext import commands

logger = settings.logging.getLogger("bot")


class NotOwner(commands.CheckFailure):
    ...


async def is_owner(ctx):
    return ctx.author.id == ctx.guild.owner_id


def is_owner2():
    async def predicate(ctx):
        if ctx.author.id != ctx.guild.owner_id:
            raise NotOwner("Hey you are not the owner")
        return True

    return commands.check(predicate)


def run():
    intents = discord.Intents.all()
    bot = commands.Bot(command_prefix="!", intents=intents)

    @bot.event
    async def on_ready():
        logger.info(f"User: {bot.user} (ID:{bot.user.id})")

    @bot.command()
    @commands.check(is_owner)
    async def say(ctx, what="WHAT?"):
        await ctx.send(what)

    # Create a locally error handling for say
    @say.error
    async def say_error(ctx, error):
        if isinstance(error, commands.CommandError):
            await ctx.send("Permission denied.")

    @bot.command()
    @is_owner2()
    # If user type !say2 with a lot of arguments, bot respond with all the arguments separated by space
    async def say2(ctx, what="WHAT?"):
        await ctx.send(what)

    # Create a locally error handling for say2
    @say2.error
    async def say2_error(ctx, error):
        if isinstance(error, NotOwner):
            await ctx.send("Permission denied.")

    bot.run(settings.DISCORD_API_SECRET, root_logger=True)


if __name__ == "__main__":
    run()
