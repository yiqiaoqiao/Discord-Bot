import settings
import discord
from discord.ext import commands
from cogs.greetings import Greetings

logger = settings.logging.getLogger("bot")


def run():
    intents = discord.Intents.all()
    bot = commands.Bot(command_prefix="!", intents=intents)

    @bot.event
    async def on_ready():
        logger.info(f"User: {bot.user} (ID:{bot.user.id})")

        # Load cogs folder command files
        for cogs_file in settings.COGS_DIR.glob("*.py"):  # only go over the py files
            if cogs_file.name != "__init__.py":
                await bot.load_extension(f"cogs.{cogs_file.name[:-3]}")

    # Using this command, you don't need stop the program and restart it when you make changes in greetings
    # You can just type !reload greetings to restart the program
    @bot.command()
    async def reload(ctx, cogs: str):
        await bot.reload_extension(f"cogs.{cogs.lower()}")

    # If you type !load greetings, you can now user the greetings commands
    @bot.command()
    async def load(ctx, cogs: str):
        await bot.load_extension(f"cogs.{cogs.lower()}")

    # If you type !unload greetings, all the things in greetings cannot be used by the bot
    @bot.command()
    async def unload(ctx, cogs: str):
        await bot.unload_extension(f"cogs.{cogs.lower()}")

    bot.run(settings.DISCORD_API_SECRET, root_logger=True)


if __name__ == "__main__":
    run()
