import settings
import discord
from discord.ext import commands

logger = settings.logging.getLogger("bot")


def run():
    intents = discord.Intents.all()
    bot = commands.Bot(command_prefix="!", intents=intents)

    @bot.event
    async def on_ready():
        logger.info(f"User: {bot.user} (ID:{bot.user.id})")

    # Bot sends direct message to user when user use !ping
    @bot.command()
    async def ping(ctx):
        await ctx.message.author.send("Hello")

    # Sometimes you do not have the context author, and we need to find/get the user first
    @bot.command()
    async def ping2(ctx):
        # Here I am trying to find the discord id yiqiaoqiao and send message to her
        user = discord.utils.get(bot.guilds[0].members, nick="yqq")
        if user:
            await user.send("Hello 2")

    bot.run(settings.DISCORD_API_SECRET, root_logger=True)


if __name__ == "__main__":
    run()
